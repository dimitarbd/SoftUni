import { get, post } from './request.js';

let endpoints = {
    allMotorcycles: '/data/motorcycles?sortBy=_createdOn%20desc',
    motorcycle: '/data/motorcycles'
};

export async function getAllMotorcycles() {
    return await get(endpoints.allMotorcycles);
}

export async function createMotorcycle(data) {
    return await post(endpoints.motorcycle, data);
}