﻿namespace TaskBoard.WebApp.Models.Task
{
    public class TaskBoardModel
    {
        public int Id { get; init; }

        public string Name { get; init; }
    }
}
