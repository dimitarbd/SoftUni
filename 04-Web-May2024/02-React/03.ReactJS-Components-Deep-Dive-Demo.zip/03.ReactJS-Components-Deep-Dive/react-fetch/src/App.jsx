import CharacterList from './components/CharacterList'
import './App.css'

function App() {

  return (
    <>
      <h1>Start Wars</h1>

      <CharacterList />
    </>
  )
}

export default App
