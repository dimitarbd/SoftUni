const express = require('express');
const { configDatabase } = require('./config/configDatabase');
const { configHbs } = require('./config/configHbs');
const { configExpress } = require('./config/configExpress');
const { configRoutes } = require('./config/configRoutes');

const { register, login } = require('./services/user');
const { createToken, verifyToken } = require('./services/jwt');

const api = require('./services/glowAlchemy');


start();

async function start() {
    const app = express();

    await configDatabase();
    configHbs(app);
    configExpress(app);
    configRoutes(app);

    app.listen(3000, () => {
        console.log('Server started http://localhost:3000');
        // test();
    });
}

async function test() {
    try {
        // REGISTER
        // const result = await register('peter@abv.bg', 'Peter', '123');
        // const token = createToken(result);
        // console.log(token);

        // const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InBldGVyQGFidi5iZyIsIl9pZCI6IjY3NWE5NjY1NWY3NGQyMzlkNjgwNjlhNiIsImlhdCI6MTczMzk4OTk4OSwiZXhwIjoxNzM0MDc2Mzg5fQ.cG7wpIy-3xa0L0vj9r4aWUFlZuxwGQObO26HFMEAsSQ'
        // const parsed = verifyToken(token)
        // console.log(parsed);

        //LOGIN
        // const result = await login('john@abv.bg', '123');
        // const token = createToken(result);
        // console.log(token);

        // CREATE RECORD
        // const result = await api.create({
        //     name: 'Radiant Glow Hydration Serum',
        //     skin: 'All skin types, including sensitive, oily, and combination.',
        //     description: 'A lightweight serum designed to deeply hydrate and brighten your skin. Formulated with premium ingredients to provide an instant boost of radiance and moisture, leaving your skin plump, smooth, and refreshed.',
        //     ingredients: 'Hyaluronic Acid / Vitamic C / Aloe Vera Extract',
        //     benefits: 'Intense Hydration: Keeps skin moisturized for up to 24 hours. Brightening Effect: Helps reduce dullness, giving a natural glow. Anti-aging Properties: Reduces fine lines and supports skin elasticity.',
        //     price: '25',
        //     image: 'https://goldleaf.nz/wp-content/uploads/2023/05/102_146_1683614016510_24CTGOLDRADIANTLIGHT_600.jpg',
        // }, '675a96183d7557854fba9e80');
        // console.log(result);

        // const data = await api.getById('675a9c44412fea8039e781ae');
        // console.log(data);

        // EDIT RECORD
        // const dataId = '675a9c44412fea8039e781ae';
        // const userId = '675a96183d7557854fba9e80';
        // const formData = {
        //     name: 'Radiant Glow Hydration Serum',
        //     skin: 'All skin types, including sensitive, oily, and combination.',
        //     description: 'A lightweight serum designed to deeply hydrate and brighten your skin. Formulated with premium ingredients to provide an instant boost of radiance and moisture, leaving your skin plump, smooth, and refreshed.',
        //     ingredients: 'Hyaluronic Acid / Vitamic C / Aloe Vera Extract',
        //     benefits: 'Intense Hydration: Keeps skin moisturized for up to 24 hours. Brightening Effect: Helps reduce dullness, giving a natural glow. Anti-aging Properties: Reduces fine lines and supports skin elasticity.',
        //     price: '26',
        //     image: 'https://goldleaf.nz/wp-content/uploads/2023/05/102_146_1683614016510_24CTGOLDRADIANTLIGHT_600.jpg',
        // }

        // const result = await api.update(dataId, formData, userId);
        // console.log(result);


        // DELETE RECORD
        // const dataId = '675a9c44412fea8039e781ae';
        // const userId = '675a96183d7557854fba9e80';

        // await api.deleteById(dataId, userId);

        //ADD TO LIST
        const dataId = '675a9da48eb477cda20dba96';
        const userId = '675a96655f74d239d68069a6';

        const result = await api.addToRecommendList(dataId, userId);
        console.log(result);

    } catch (err) {
        console.log('Caugth error!');
        console.error(err.message);
    }
}

